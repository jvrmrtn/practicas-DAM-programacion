DROP TABLE vehiculos;
DROP TABLE propietarios;


CREATE TABLE Propietarios (
	id_prop INT(11) auto_increment PRIMARY KEY,
	nombre_prop VARCHAR(100),
	dni_prop VARCHAR(9)
);

CREATE TABLE Vehiculos (
	mat_veh CHAR(7) PRIMARY KEY,
	marca_veh VARCHAR(50),
	kms_veh INT(11),
	precio_veh FLOAT(12),
	desc_veh VARCHAR(300),
	id_prop INT(11) REFERENCES Propietarios (id_prop)
);

INSERT INTO Propietarios VALUES (1,'Jose García', '80252627J');
INSERT INTO Propietarios VALUES (2,'María López', '70555258H');
INSERT INTO Propietarios VALUES (3,'Nuria Marcos', '71226631A');
INSERT INTO Propietarios VALUES (4,'Alejandro Mayo', '03625566Y');
INSERT INTO Propietarios VALUES (5,'Luis Sanz', '07823245K');

INSERT INTO Vehiculos VALUES ('0001BBC', 'HONDA', 127000, 3000.00, 'Honda Civic Hatchback del 94 gris perlado.', 1);
INSERT INTO Vehiculos VALUES ('0115JFK', 'FIAT', 89000, 6000.00, 'Fiat Punto del 04 rojo fuego.', 2);
INSERT INTO Vehiculos VALUES ('9989JMG', 'FORD', 67500, 7000.00, 'Ford Ka del 15 blanco marfil.', 2);
INSERT INTO Vehiculos VALUES ('5556RDH', 'NISSAN', 189000, 12000.00, 'Nissan Juke del 12 negro mate.', 3);
INSERT INTO Vehiculos VALUES ('1898GSW', 'RENAULT', 42250, 17000.00, 'Renault Clio Sport del 16 amarillo racing.', 4);
INSERT INTO Vehiculos VALUES ('0549MTB', 'FORD', 136000, 10000.00, 'Ford Fiesta del 17 azul marino.', 4);
INSERT INTO Vehiculos VALUES ('6377KBL', 'VOLKSWAGEN', 32000, 13500.00, 'Volkswagen Golf 2.0 del 18 blanco satinado.', 4);
INSERT INTO Vehiculos VALUES ('8220HWK', 'BMW', 115000, 25000.00, 'Bmw 318 iS del 18 granate brillo.', 5);